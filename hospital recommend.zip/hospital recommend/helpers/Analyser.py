

from PyQt5 import QtCore, QtGui, QtWidgets
import requests
import json
from PyQt5.QtWidgets import QMessageBox

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(942, 569)
        Dialog.setStyleSheet("background-color: #2C3336;\n"
"font: 63 12pt \"Nunito\";")
        self.ResourceBrower = QtWidgets.QTextBrowser(Dialog)
        self.ResourceBrower.setGeometry(QtCore.QRect(20, 170, 291, 391))
        self.ResourceBrower.setStyleSheet("background-color: white;\n"
"border-radius: 10px;")
        self.ResourceBrower.setObjectName("ResourceBrower")
        self.ZoneBrowser = QtWidgets.QTextBrowser(Dialog)
        self.ZoneBrowser.setGeometry(QtCore.QRect(650, 170, 281, 381))
        self.ZoneBrowser.setStyleSheet("background-color: white;\n"
"border-radius: 10px;")
        self.ZoneBrowser.setObjectName("ZoneBrowser")
        self.heading = QtWidgets.QLabel(Dialog)
        self.heading.setGeometry(QtCore.QRect(360, 10, 241, 41))
        self.heading.setStyleSheet("color: cyan;\n"
"font: 81 24pt \"Nunito ExtraBold\";\n"
"")
        self.heading.setObjectName("heading")
        self.Visualiser = QtWidgets.QPushButton(Dialog)
        self.Visualiser.setGeometry(QtCore.QRect(420, 490, 101, 31))
        self.Visualiser.setStyleSheet("border-radius:10px;\n"
"background-color: #3CB7A1;\n"
"color: white;")
        self.Visualiser.setObjectName("Visualiser")
        self.heading_2 = QtWidgets.QLabel(Dialog)
        self.heading_2.setGeometry(QtCore.QRect(90, 120, 221, 31))
        self.heading_2.setStyleSheet("color: cyan;\n"
"font: 81 24pt \"Nunito ExtraBold\";\n"
"")
        self.heading_2.setObjectName("heading_2")
        self.heading_3 = QtWidgets.QLabel(Dialog)
        self.heading_3.setGeometry(QtCore.QRect(730, 120, 131, 31))
        self.heading_3.setStyleSheet("color: cyan;\n"
"font: 81 24pt \"Nunito ExtraBold\";\n"
"")
        self.heading_3.setObjectName("heading_3")

        font = QtGui.QFont()
        font.setFamily("Nunito")
        font.setPointSize(12)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(7)
        
        self.CitySearch = QtWidgets.QPushButton(Dialog)
        self.CitySearch.setGeometry(QtCore.QRect(430, 230, 101, 31))
        self.CitySearch.setStyleSheet("border-radius:10px;\n"
"background-color: #3CB7A1;\n"
"color: white;")
        self.CitySearch.setObjectName("CitySearch")
        self.heading_4 = QtWidgets.QLabel(Dialog)
        self.heading_4.setGeometry(QtCore.QRect(430, 110, 131, 41))
        self.heading_4.setStyleSheet("color: cyan;\n"
"font: 81 24pt \"Nunito ExtraBold\";\n"
"")
        self.heading_4.setObjectName("heading_4")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        self.CitySearch.clicked.connect(self.getresource)
    def getresource(self):
        try:
            a=requests.get('https://api.covid19india.org/resources/resources.json')
            b=a.text
            s=json.loads(b)
            data=s["resources"]
            y=" "
            xu=" "
            for i in range(0,len(data)):
                x=data[i]
                if x["state"]=="Kerala":
                    y=y+x["category"]+"\n"+x["descriptionandorserviceprovided"]+"\n"+x["city"]+"\n"+x["phonenumber"]+"\n"+x["nameoftheorganisation"]+"\n"+"----"+"\n"
                else:
                    continue
                
            ab=requests.get('https://api.covid19india.org/zones.json')
            b=ab.text
            s2=json.loads(b)
            z=s2["zones"]
            for i in range(0,734):
                y3=z[i]
                if y3["statecode"]=="KL":
                    xu=xu+y3["district"]+"-"+y3["zone"]+"\n"+"---"+"\n"
            self.ZoneBrowser.append(str(xu))
            self.ResourceBrower.append(str(y))
        except:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Error")
            msg.setInformativeText("Check the spelling and try again!")
            msg.setWindowTitle('Error')
            msg.exec_()
        
            
        
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.heading.setText(_translate("Dialog", "HospAnalyser"))
        self.Visualiser.setText(_translate("Dialog", "Visualiser"))
        self.heading_2.setText(_translate("Dialog", "Resources"))
        self.heading_3.setText(_translate("Dialog", "Zones"))
        
        self.CitySearch.setText(_translate("Dialog", "Search"))
       


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
